#include "my_frame.h"



/**
 * The wxFrame constructor has non-default arguments that must be set, one of 
 * them is the title.
 */
MyFrame::MyFrame(const wxString &title) 
        : wxFrame((wxFrame*) NULL, wxID_ANY, title) {

}



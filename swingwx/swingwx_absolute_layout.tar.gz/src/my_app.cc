#include "my_app.h"
#include "my_frame.h"


// EVENTS **********************************************************************


/**
 * Executes application initialization code.
 *
 * @return <code>true</code> if everything is OK; <code>false</code> 
 * otherwise
 */
bool MyApp::OnInit() {
    
    // check MyFrame's constructor to see why you must provide a frame title
    MyFrame *frame = new MyFrame("wxWidgets test");

    frame->Show();
    
    return true;
}


IMPLEMENT_APP(MyApp);



#include "my_frame.h"

#include <wx/panel.h>  


/**
 * The wxFrame constructor has non-default arguments that must be set, one of 
 * them is the title.
 */
MyFrame::MyFrame(const wxString &title) 
        : wxFrame((wxFrame*) NULL, wxID_ANY, title) {

    new wxPanel(this, wxID_ANY, wxPoint(20, 20), wxSize(80, 120), wxSUNKEN_BORDER);  
    new wxPanel(this, wxID_ANY, wxPoint(120, 20), wxSize(80, 120), wxRAISED_BORDER);  
}



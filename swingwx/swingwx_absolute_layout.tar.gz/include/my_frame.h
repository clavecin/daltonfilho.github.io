#ifndef _MY_FRAME_H
#define	_MY_FRAME_H


#include <wx/frame.h>


/**
 * A simple frame used to demonstrate wxWidgets features.
 * 
 * @author Dalton Filho
 * @since 12/2007
 * @see http://www.daltonfilho.com/articles/swingwx
 */
class MyFrame : public wxFrame {
    
    
public:

    
    /**
     * Constructs a frame with the given <code>title</code>.
     * 
     * @param title a title
     */
    MyFrame(const wxString& title);
    
    
};


#endif	/* _MY_FRAME_H */


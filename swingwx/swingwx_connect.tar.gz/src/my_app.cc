#include "my_app.h"
#include "my_frame.h"


IMPLEMENT_APP(MyApp);


// EVENTS **********************************************************************


/**
 * Executes application initialization code.
 *
 * @return <code>true</code> if everything is OK; <code>false</code> 
 * otherwise
 */
bool MyApp::OnInit() {
    
    // check MyFrame's constructor to see why you must provide a frame title
    MyFrame *frame = new MyFrame("wxWidgets test");
    
    // This class inherits wxEvtHandler, so it follows the rules
    frame->addLeftButtonHandler(wxCommandEventHandler(MyApp::onFrameLeftButtonClicked), this);
    
    frame->Show();
    
    return true;
}

/**
 * Called when the left button of the main frame is clicked.
 *
 * @param event a command event
 */
void MyApp::onFrameLeftButtonClicked(wxCommandEvent &event) {
    event.Skip();
    wxBell();
}


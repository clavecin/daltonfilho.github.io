#ifndef _MY_APP_H
#define	_MY_APP_H


#include <wx/app.h>


/**
 * The application class of the wxWidgets tutorial.
 * 
 * @author Dalton Filho
 * @since 12/2007
 * @see http://www.daltonfilho.com/articles/swingwx
 */
class MyApp : public wxApp {
    

public:
    
    
    // EVENTS ******************************************************************
    
    
    /**
     * Executes application initialization code.
     *
     * @return <code>true</code> if everything is OK; <code>false</code> 
     * otherwise
     */
    virtual bool OnInit();
    
    /**
     * Called when the left button of the main frame is clicked.
     *
     * @param event a command event
     */
    void onFrameLeftButtonClicked(wxCommandEvent &event);

    
};


#endif	/* _MY_APP_H */


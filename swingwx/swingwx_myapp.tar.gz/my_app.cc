#include "my_app.h"
#include "my_frame.h"


IMPLEMENT_APP(MyApp);


/**
 * Executes application initialization code.
 *
 * @return <code>true</code> if everything is OK; <code>false</code> 
 * otherwise
 */
bool MyApp::OnInit() {
    return true;
}


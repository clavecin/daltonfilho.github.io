#include "my_frame.h"

#include <wx/sizer.h>
#include <wx/colordlg.h>
#include <wx/msgdlg.h>


// WX WIDGETS EVENT TABLE ******************************************************

 
BEGIN_EVENT_TABLE(MyFrame, wxFrame)

    EVT_BUTTON(wxID_LEFT_BUTTON, MyFrame::changeParentPanelColor)
    EVT_BUTTON(wxID_RIGHT_BUTTON, MyFrame::changeParentPanelColor)
    EVT_BUTTON(wxID_RIGHT_BUTTON, MyFrame::showHelloMessage)

END_EVENT_TABLE()


// CONSTRUCTOR *****************************************************************


/**
 * The wxFrame constructor has non-default arguments that must be set, one of 
 * them is the title.
 */
MyFrame::MyFrame(const wxString &title) 
        : wxFrame((wxFrame*) NULL, wxID_ANY, title),
          leftPanel(NULL), rightPanel(NULL), leftButton(NULL), rightButton(NULL) {
            
    initPanels();
    initButtons();
}


// INITIALIZATION **************************************************************
        

/**
 * Initializes two panels that must maintain a fixed distance of 20 pixels from
 * each other and from the frame's borders.
 */        
void MyFrame::initPanels() {
    wxBoxSizer *sizer = new wxBoxSizer(wxHORIZONTAL);
    
    leftPanel = new wxPanel(this, wxID_LEFT_PANEL);
    rightPanel = new wxPanel(this, wxID_LEFT_PANEL);
    
    leftPanel->SetMinSize(wxSize(180, 120));
    rightPanel->SetMinSize(wxSize(180, 120));
    
    sizer->Add(leftPanel, true, wxEXPAND | wxTOP | wxBOTTOM | wxLEFT, 20);
    sizer->AddSpacer(20);
    sizer->Add(rightPanel, true, wxEXPAND | wxTOP | wxBOTTOM | wxRIGHT, 20);
    
    leftPanel->SetBackgroundColour(wxColour(255, 255, 0));
    rightPanel->SetBackgroundColour(wxColour(255, 0, 255));
    
    sizer->SetSizeHints(this);
    
    SetSizer(sizer);
}

/**
 * Initializes two buttons and adds one per panel.
 */
void MyFrame::initButtons() {
    leftButton = new wxButton(leftPanel, wxID_LEFT_BUTTON, _T("Left button"));
    rightButton = new wxButton(rightPanel, wxID_RIGHT_BUTTON, _T("Right button"));
    
    wxBoxSizer *leftSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer *rightSizer = new wxBoxSizer(wxVERTICAL);
    
    leftButton->SetMinSize(wxSize(130, 30));
    rightButton->SetMinSize(wxSize(130, 30));
    
    leftSizer->AddStretchSpacer();
    leftSizer->Add(leftButton, false, wxEXPAND | wxALL, 20);
    leftSizer->AddStretchSpacer();
    
    rightSizer->AddStretchSpacer();
    rightSizer->Add(rightButton, false, wxEXPAND | wxALL, 20);
    rightSizer->AddStretchSpacer();
    
    leftSizer->SetSizeHints(leftPanel);
    rightSizer->SetSizeHints(rightPanel);
    
    leftPanel->SetSizer(leftSizer);
    rightPanel->SetSizer(rightSizer);
}


// EVENTS **********************************************************************


/**
 * Shows a color selection dialog and uses that color as the background for
 * the parent panel of the button that sends this command. 
 *
 * @param event a command event
 */
void MyFrame::changeParentPanelColor(wxCommandEvent &event) {
    event.Skip(true);
    
    wxButton *button = static_cast<wxButton*>(event.GetEventObject());
    wxWindow *parent = button->GetParent();
    
    wxColour colour = wxGetColourFromUser(parent, parent->GetBackgroundColour());
    
    parent->SetBackgroundColour(colour);
}

/**
 * Shows a hello message.
 *
 * @param event a command event 
 */
void MyFrame::showHelloMessage(wxCommandEvent &event) {
    event.Skip(true);
    
    wxButton *button = static_cast<wxButton*>(event.GetEventObject());
    wxMessageBox(_T("Hello!"), _T("Event test"), wxOK | wxICON_INFORMATION, button);
}

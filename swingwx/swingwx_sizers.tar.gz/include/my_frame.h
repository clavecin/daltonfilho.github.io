#ifndef _MY_FRAME_H
#define	_MY_FRAME_H


#include <wx/frame.h>
#include <wx/panel.h>
#include <wx/button.h>


/**
 * A simple frame used to demonstrate wxWidgets features.
 * 
 * @author Dalton Filho
 * @since 12/2007
 * @see http://www.daltonfilho.com/articles/swingwx
 */
class MyFrame : public wxFrame {
    
    
public:
    

    // CONSTRUCTOR *************************************************************
    
    
    /**
     * Constructs a frame with the given <code>title</code>.
     * 
     * @param title a title
     */
    MyFrame(const wxString &title);
    
    
private:
    
    
    // ENUMS *******************************************************************
    
    
    /**
     * IDs that will be used later for event handling. Note that these IDs do 
     * not have to be unique across your entire application. Just make sure they
     * are always positive (otherwise wxWidgets will generate another ID) and 
     * that they are unique within the scope of your class.
     */
    enum {
        wxID_LEFT_PANEL = wxID_HIGHEST + 1,
        wxID_RIGHT_PANEL,
        wxID_LEFT_BUTTON,
        wxID_RIGHT_BUTTON
    };
    
    
    // INITIALIZATION **********************************************************
    
    
    /**
     * Initializes two panels that must maintain a fixed distance of 20 pixels 
     * from each other and from the frame's borders.
     */        
    void initPanels();
    
    /**
     * Initializes two buttons and adds one per panel.
     */
    void initButtons();
    
          
    // ATTRIBUTES **************************************************************
    
    
    /**
     * The panel that remains on the left.
     */
    wxPanel *leftPanel;
    
    /**
     * The panel that remains on the right.
     */
    wxPanel *rightPanel;
    
    /**
     * The button that remains on the left panel.
     */
    wxButton *leftButton;
    
    /**
     * The button that remains on the right panel.
     */
    wxButton *rightButton;
    
        
    
};


#endif	/* _MY_FRAME_H */

